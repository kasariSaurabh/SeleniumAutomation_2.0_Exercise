package junitFW;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GmailLoginTest {
	
	private WebDriver driver;
	
	@BeforeEach
	 public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://gmail.com");
	}

	@AfterEach
	public void tearDown() throws Exception {
		Thread.sleep(2000);
		driver.quit();
	}

	@Test
	public void verifylogin() {
		driver.findElement(By.name("identifier")).sendKeys("testingse2");
		driver.findElement(By.xpath("//*[@id='identifierNext']/span/span")).click();
		driver.findElement(By.name("password")).sendKeys("Selenium5");
		driver.findElement(By.xpath("//*[@id='passwordNext']/span/span")).click();
	}
	
	@Test
	public void verifylogout() {
		driver.findElement(By.xpath("//*[@id='gb']/div[2]/div[3]/div/div[2]/div/a/span")).click();
		driver.findElement(By.id("gb_71")).click();
	}
}
