package junitFW;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GmailSearch {
	private WebDriver driver;
	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://gmail.com");
	}

	@After
	public void tearDown() throws Exception {
		Thread.sleep(2000);
		driver.quit();
	}

	public void login() throws Exception {
		driver.findElement(By.name("identifier")).sendKeys("testingse2");
		driver.findElement(By.xpath("//*[@id='identifierNext']/span/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.name("password")).sendKeys("Selenium5");
		driver.findElement(By.xpath("//*[@id='passwordNext']/span/span")).click();
		Thread.sleep(2000);
	}
	
	@Test
	public void logout() throws Exception {
		login();
		driver.findElement(By.xpath("//*[@id='gb']/div[2]/div[3]/div/div[2]/div/a/span")).click();
		driver.findElement(By.id("gb_71")).click();
	}
	

}
