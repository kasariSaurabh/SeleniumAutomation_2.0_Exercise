package webdriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SpicejetSearch {
	
	private WebDriver driver;
		
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "D://lib//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	public void openURL() {
		driver.get("https://www.spicejet.com/");
	}
	
	public void onewayTrip() throws Exception {

		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
		driver.findElement(By.linkText("Hyderabad (HYD)")).click();
		driver.findElement(By.linkText("Bengaluru (BLR)")).click();
		driver.findElement(By.linkText("23")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("divpaxinfo")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("hrefIncAdt")).click();
		driver.findElement(By.id("hrefIncChd")).click();
		driver.findElement(By.id("hrefIncInf")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("btnclosepaxoption")).click();
		new Select(driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency"))).selectByVisibleText("USD");
		Thread.sleep(2000);
		driver.findElement(By.id("ctl00_mainContent_btn_FindFlights")).click();
	}
	
	public void roundTrip() throws Exception {
		driver.findElement(By.xpath("//*[@id=\"divsearchdisplay\"]/div[2]/div[3]/span")).click();
		driver.findElement(By.id("AvailabilitySearchInputSelectView_RoundTrip")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("AvailabilitySearchInputSelectView_ButtonSubmit")).click();
	}
	
	public void close() {
		driver.quit();
	}
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		SpicejetSearch s = new SpicejetSearch();
		s.openBrowser();
		s.openURL();
		s.onewayTrip();
		Thread.sleep(2000);
		s.roundTrip();
		Thread.sleep(5000);
		s.close();
		
	}

}
