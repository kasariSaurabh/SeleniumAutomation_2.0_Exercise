package webdriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Selenium4links_Parameter {

	private WebDriver driver;
	
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	 
	public void openURL() {
		driver.get("http://selenium4testing.com");
		driver.findElement(By.id("closediv")).click();
	}
	
	public void click(String str) {
		driver.findElement(By.linkText(str)).click();
	}
	
	public void close() {
		driver.quit();
	}
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Selenium4links_Parameter p = new Selenium4links_Parameter();
			p.openBrowser();
			p.openURL();
			p.click("Manual FAQs");
			Thread.sleep(1000);
			p.click("Selenium FAQs");
			Thread.sleep(1000);
			p.click("Core Java FAQs");
			Thread.sleep(1000);
			p.click("Downloads");
			Thread.sleep(1000);
			p.close();
	}

}
