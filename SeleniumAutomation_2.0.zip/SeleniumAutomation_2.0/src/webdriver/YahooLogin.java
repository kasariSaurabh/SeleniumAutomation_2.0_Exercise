package webdriver;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class YahooLogin {
	
	private WebDriver driver;
	
	public void enter() throws Exception {
		Robot r= new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);
	}
	
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "D://lib//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	public void openURL() {
		driver.get("https://login.yahoo.com/?.src=ym&.lang=en-US&.intl=us&.done=https%3A%2F%2Fmail.yahoo.com%2Fd");
	}
	
	public void login() throws Exception {
		driver.findElement(By.id("login-username")).sendKeys("selenium4u");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id='login-signin']")).submit();
		Thread.sleep(500);
		driver.findElement(By.id("login-passwd")).sendKeys("selenium@123");
		enter();
	}
	
	public void close() {
		driver.findElement(By.xpath("//*[@id=\'ybar\']/div[3]/div[1]/div/label/span")).click();
		driver.findElement(By.xpath("//*[@id=\'ybarAccountMenuBody\']/a[3]/span")).click();
		driver.close();
	}
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		YahooLogin l = new YahooLogin();
		l.openBrowser();
		l.openURL();
		l.login();
		Thread.sleep(5000);
		l.close();
		
	}

}
