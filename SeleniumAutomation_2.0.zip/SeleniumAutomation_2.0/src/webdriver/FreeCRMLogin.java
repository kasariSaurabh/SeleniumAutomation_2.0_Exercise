package webdriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FreeCRMLogin {
	
	private WebDriver driver;
	
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "D://lib//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	public void openURL() {
		driver.get("https://ui.freecrm.com");
	}
	
	public void login() throws Exception {
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div/form/div/div[1]/div/input")).sendKeys("nag010683@gmail.com");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div/form/div/div[2]/div/input")).sendKeys("Nagesh@123");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div/form/div/div[3]")).click();
	}
	
	public void logout() {
		driver.findElement(By.xpath("//*[@id=\'top-header-menu\']/div[2]/div[2]/div")).click();
		driver.findElement(By.xpath("//*[@id=\'top-header-menu\']/div[2]/div[2]/div/div[2]/a[4]/span")).click();
		driver.quit();
	}
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		FreeCRMLogin c = new FreeCRMLogin();
		c.openBrowser();
		c.openURL();
		c.login();
		Thread.sleep(2000);
		c.logout();
		Thread.sleep(500);
	}

}
