package webdriver;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HRM_Registration {
	
	private WebDriver driver;
	
	public void enter() throws Exception{
		Robot r= new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
	}
	
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
	}
	public void openURL() {
		driver.get("http://www.sentrifugo.com/");
	}
	
	public void register() throws Exception {
		driver.findElement(By.linkText("Register")).click();
		driver.findElement(By.id("emailaddress")).sendKeys("nag010683@gmail.com");
		driver.findElement(By.id("newpassword")).sendKeys("Nagesh@123");
		driver.findElement(By.id("passwordagain")).sendKeys("Nagesh@123");
		driver.findElement(By.id("first_name")).sendKeys("Mahesh");
		driver.findElement(By.id("last_name")).sendKeys("Reddy");
		driver.findElement(By.id("username")).sendKeys("Nagesh@123");
		driver.findElement(By.id("s2id_gender")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='select2-drop']/div/input")).sendKeys("Male");
		//Thread.sleep(1000);
		enter();
		driver.findElement(By.id("jobtitle")).sendKeys("QA Automation");
		driver.findElement(By.id("companyname")).sendKeys("Mind Q");
		driver.findElement(By.id("s2id_industry")).click();
		driver.findElement(By.xpath("//*[@id='select2-drop']/div/input")).sendKeys("Automotive");
		enter();
		
		driver.findElement(By.xpath("//*[@id=\'s2id_no_of_employees\']/a/span")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'select2-drop\']/ul/li[4]/div")).click();
		
		driver.findElement(By.id("companyphonenumber")).sendKeys("9668574214");
		driver.findElement(By.id("compaddress")).sendKeys("SR Nagar, Ameerpet, Hyderabad");
		
		driver.findElement(By.xpath("//*[@id=\'s2id_country\']/a")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\'select2-drop\']/ul/li[101]/div")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\'s2id_state\']/a/span")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\'select2-drop\']/ul/li[2]/div")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'s2id_city\']/a/span")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'select2-drop\']/ul/li[12]/div")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'s2id_hearabout\']/a/span")).click();
		driver.findElement(By.xpath("//*[@id=\'select2-drop\']/ul/li[4]/div")).click();
		Thread.sleep(500);
		driver.findElement(By.id("skype")).sendKeys("mahesh_3054");
		driver.findElement(By.id("regbutton")).click();
	}
	
	public void close() throws Exception {
		Thread.sleep(1000);
		driver.quit();
	}
	
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		HRM_Registration h = new HRM_Registration();
		h.openBrowser();
		h.openURL();
		h.register();
		h.close();
	}

}
