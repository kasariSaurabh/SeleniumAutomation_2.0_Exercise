package webdriver;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Robot_Ex {
	
	private WebDriver driver;
	
	public void enter() throws Exception {
		 Robot r= new Robot();
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
			
			r.keyPress(KeyEvent.VK_TAB);
			r.keyRelease(KeyEvent.VK_TAB);
	}
	
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		driver = new ChromeDriver(); //Open Browser
		driver.manage().window().maximize();
	}
	
	public void openURL() {
		driver.get("http://google.co.in"); // Open URL
	}
	
	public void search() {
		driver.findElement(By.name("q")).sendKeys("selenium4testing");
		//driver.findElement(By.name("q")).submit();
	}
	
	public void close() {
		driver.quit();
	}
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Robot_Ex e = new Robot_Ex();
		e.openBrowser();
		e.openURL();
		e.search();
		e.enter();
		Thread.sleep(5000);
		e.close();
			
	}

}
