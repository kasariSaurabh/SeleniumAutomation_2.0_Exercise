package webdriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HRMLogin {
	
	private WebDriver driver;
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	public void openURL() {
		driver.get("http://www.sentrifugo.com/");
	}
	
	public void login() {
		driver.findElement(By.linkText("Sign in")).click();
		driver.findElement(By.id("Form_Email")).sendKeys("nag010683@gmail.com");
		driver.findElement(By.id("Form_Password")).sendKeys("Nagesh@123");
		driver.findElement(By.id("Form_SignIn")).click();
	}
	
	public void logout() {
		driver.findElement(By.id("logoutbutton")).click();
		driver.findElement(By.xpath("//*[@id='logoutid']/span[3]")).click();
	}
	
	public void closeBrowser() {
		driver.quit();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HRMLogin h = new HRMLogin();
		h.openBrowser();
		h.openURL();
		h.login();
		h.logout();
		h.closeBrowser();
	}

}
