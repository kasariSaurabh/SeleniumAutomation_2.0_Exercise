package webdriver;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FreeCRMContact {
	
	private WebDriver driver;
	
	public void enter() throws Exception {
		Robot r= new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);
	}
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver","D:\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	
	public void openURL() {
		driver.get("https://ui.freecrm.com");
	}
	
	public void login() throws Exception {
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div/form/div/div[1]/div/input")).sendKeys("nag010683@gmail.com");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div/form/div/div[2]/div/input")).sendKeys("Nagesh@123");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div/form/div/div[3]")).click();
		Thread.sleep(1000);
	}
	
	public void contacts() throws Exception {
		
		driver.findElement(By.xpath("//*[@id=\'main-nav\']/a[3]/span")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'dashboard-toolbar\']/div[2]/div/a/button")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[1]/div[1]/div/div/input")).sendKeys("Venktesh");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[1]/div[2]/div/div/input")).sendKeys("Babu");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[2]/div[1]/div/div/input")).sendKeys("Reddy");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[2]/div[2]/div/div/input")).sendKeys("Oracle Inc.");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[3]/div[2]/div/label[2]/div/input")).sendKeys("selenium");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[3]/div[2]/div/label[2]/div/div[2]/div/span")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[3]/div[2]/div/label[2]/div/input")).sendKeys("QA Team");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[3]/div[2]/div/label[2]/div/div[2]/div/span")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[4]/div/div/div/div/div[1]/input")).sendKeys("venktesh0065@gmail.com");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[5]/div/div/textarea")).sendKeys("Automation Testing means using an automation tool to execute your test case suite.");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[6]/div[1]/div/div/div/div[1]/i")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[6]/div[1]/div/div/div/div[1]/div[2]/div[2]/span")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[6]/div[1]/div/div/div/div[2]/input")).sendKeys("https://www.facebook.com/venktesh.reddy2");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[6]/div[2]/div/div/input")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[6]/div[2]/div/div/div[2]/div[234]/span")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[8]/div/div/div/div[1]/div/input")).sendKeys("SR Nagar, Ameerpet, Hyderabad");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[8]/div/div/div/div[2]/div/input")).sendKeys("Hyderabad");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[8]/div/div/div/div[3]/div/input")).sendKeys("Andhra Pradesh");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[8]/div/div/div/div[4]/div/input")).sendKeys("500038");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[8]/div/div/div/div[5]/div/i")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[8]/div/div/div/div[5]/div/div[2]/div[100]/span")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[9]/div[1]/div/div/div/div[1]/i")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[9]/div[1]/div/div/div/div[1]/div[2]/div[100]/span")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[9]/div[1]/div/div/div/div[2]/input")).sendKeys("6857412425");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[9]/div[1]/div/div/div/div[3]/input")).sendKeys("6857412865");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[9]/div[2]/div/div/input")).sendKeys("Automation Engineer");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[10]/div[1]/div/div/input")).sendKeys("Automation Testing Team");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[10]/div[2]/div/div/input")).sendKeys("Srinivas");
		Thread.sleep(1000);
		//driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[10]/div[2]/div/div/div[2]/div[2]/span")).click();
		enter();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[11]/div[1]/div/div/input")).sendKeys("Srinivas");
		Thread.sleep(500);
		//driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[11]/div[1]/div/div/div[2]/div[2]/span")).click();
		enter();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[11]/div[2]/div/div/input")).sendKeys("Srinivas");
		Thread.sleep(1000);
		//driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[11]/div[2]/div/div/div[2]/div[2]/span")).click();
		enter();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[12]/div[1]/div/div/i")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[12]/div[1]/div/div/div[2]/div[1]/span")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[12]/div[2]/div/div/i")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[12]/div[2]/div/div/div[2]/div[1]/span")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[13]/div[1]/div/div/i")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[13]/div[1]/div/div/div[2]/div[2]/span")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[13]/div[2]/div/div/label")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[14]/div[1]/div/div/label")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[14]/div[2]/div/div/label")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[15]/div[1]/div/div/div[1]/input")).sendKeys("10");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[15]/div[1]/div/div/div[2]/i")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[15]/div[1]/div/div/div[2]/div[2]/div[3]/span")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[15]/div[1]/div/div/div[3]/input")).sendKeys("1993");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[15]/div[2]/div/div/input")).sendKeys("N/A");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[16]/div/div/div/div/input")).sendKeys("adorable-cute-love-quotes.jpg");
		Thread.sleep(1000);
	}
	
	public void saveData() throws Exception {
		driver.findElement(By.xpath("//*[@id=\'dashboard-toolbar\']/div[2]/div/button[2]")).click();
		Thread.sleep(8000);
	}
	
	public void logout() throws Exception {
		driver.findElement(By.xpath("//*[@id=\'top-header-menu\']/div[2]/div[2]/div")).click();
		driver.findElement(By.xpath("//*[@id=\'top-header-menu\']/div[2]/div[2]/div/div[2]/a[4]/span")).click();
		Thread.sleep(2000);
		driver.quit();
	}
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		FreeCRMContact c = new FreeCRMContact();
		c.openBrowser();
		c.openURL();
		c.login();
		c.contacts();
		c.saveData();
		c.logout();
	}

}
