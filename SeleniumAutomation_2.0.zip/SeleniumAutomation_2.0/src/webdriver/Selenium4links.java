package webdriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Selenium4links {
	
	private WebDriver driver;
	
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
	}
	
	public void openURL() throws Exception {
		driver.get("http://selenium4testing.com");
		Thread.sleep(1000);
		driver.findElement(By.id("closediv")).click();
	}
	
	public void mFAQS() {
		driver.findElement(By.linkText("Manual FAQs")).click();
	}
	
	public void sFAQS() {
		driver.findElement(By.linkText("Selenium FAQs")).click();
	}
	
	public void cFAQS() {
		driver.findElement(By.linkText("Core Java FAQs")).click();
	}
	
	public void close() {
		driver.quit();
	}
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Selenium4links s=new Selenium4links();
		s.openBrowser();
		s.openURL();
		s.mFAQS();
		Thread.sleep(2000);
		s.sFAQS();
		Thread.sleep(2000);
		s.cFAQS();
		Thread.sleep(2000);
		s.close();
		
	}

}
