package webdriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GmailLogin {
	private WebDriver driver;
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global wait
	}
	
	public void openURL() {
		driver.get("http://gmail.com");
		
	}
	
	public void login() throws Exception {
		driver.findElement(By.name("identifier")).sendKeys("testingse2");
		driver.findElement(By.xpath("//*[@id='identifierNext']/span/span")).click();
		driver.findElement(By.name("password")).sendKeys("Selenium5");
		Thread.sleep(2000); //2 secs
		driver.findElement(By.xpath("//*[@id='passwordNext']/span/span")).click();
	}
	
	public void logout() {
		driver.findElement(By.xpath("//*[@id='gb']/div[2]/div[3]/div/div[2]/div/a/span")).click();
		driver.findElement(By.id("gb_71")).click();
		
	}
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		GmailLogin g = new GmailLogin();
		g.openBrowser();
		g.openURL();
		g.login();
		g.logout();
	}

}
