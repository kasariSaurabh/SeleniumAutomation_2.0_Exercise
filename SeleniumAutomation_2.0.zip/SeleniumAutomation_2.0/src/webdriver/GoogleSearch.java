package webdriver;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleSearch {
	
	private WebDriver driver;
	
	public void robotEnter() throws Exception {
		Robot r= new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);
	}
	public void openBrowser() {
		 System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global Wait
	}
	
	public void openURL() {
		driver.get("http://google.co.in");
	}
	
	public void search() throws Exception {
		driver.findElement(By.name("q")).sendKeys("selenium4testing");
		Thread.sleep(1000); // one second
		robotEnter();
		Thread.sleep(10000);
		driver.quit();
	
	}
	
	public static void main(String[] args) throws Exception  {
		// TODO Auto-generated method stub
		GoogleSearch g = new GoogleSearch();
		g.openBrowser();
		g.openURL();
		g.search();
	}

}
