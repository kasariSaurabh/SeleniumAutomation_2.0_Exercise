package testingArt;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SearchNumberOfPage {

	public static void main(String[] args) throws Exception {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Search Keyword:");
		String str=sc.nextLine();
		System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.co.in/");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.name("q")).sendKeys(str);
		driver.findElement(By.name("btnK")).click();
		Thread.sleep(3000);
		int c=0;
		try 
		{
			while(driver.findElement(By.xpath("//*[text()='Next']")).isDisplayed()) {
				driver.findElement(By.xpath("//*[text()='Next']")).click();
				Thread.sleep(3000);
				c=c+1;
			}
			
		}
		catch(Exception e) 
		{
			System.out.println("Link Varification is Compleated");
		}
		System.out.println(c);
		sc.close();
		driver.close();
	}
}
