package testingArt;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;

public class testScroll {
	WebDriver driver;
	
  @Test
  public void f() throws Exception {
	  
	  driver.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();
	  WebElement searchBox = driver.findElement(By.name("q"));
	  searchBox.sendKeys("Buddha");
	  WebElement searchButton = driver.findElement(By.className("vh79eN"));
	  searchButton.click();
	  Thread.sleep(2000);
	  
	  //Scroll down the webpage by 2500 pixels
	  JavascriptExecutor js = (JavascriptExecutor)driver;
	  js.executeScript("scrollBy(0, 2500)");
	  
	  //Waiting till page:2 text is visible
	  WebElement pageNumberdisplayer = (new WebDriverWait(driver, 10)).until
	  (ExpectedConditions.presenceOfElementLocated(By.cssSelector("div#container")));
	  
	  //Verifying that page got scrolled  and "page-2" text is visible now 
	  //and more products become visible
	  Assert.assertEquals(pageNumberdisplayer.getText(), "Page: 2");
	  
	  
  }
  @BeforeTest
  public void beforeTest() {
	  
	  System.setProperty("webdriver.chrome.driver", "D:\\chrome77\\chromedriver_win32\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global wait
	  driver.get("http://www.flipkart.com");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  //Thread.sleep(2000);
	  //driver.quit();
  }

}
