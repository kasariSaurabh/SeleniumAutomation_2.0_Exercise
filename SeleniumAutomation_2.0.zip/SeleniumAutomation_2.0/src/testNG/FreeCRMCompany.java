package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class FreeCRMCompany {
	
	WebDriver driver;
	
  @Test(description = "Verify Login functionality")
  public void verify1() throws Exception {
	  	driver.findElement(By.xpath("//*[@id=\'ui\']/div/div/form/div/div[1]/div/input")).sendKeys("nag010683@gmail.com");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div/form/div/div[2]/div/input")).sendKeys("Nagesh@123");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div/form/div/div[3]")).click();
		Thread.sleep(1000);
  }
  
  @Test(description = "Verify Company Details functionality")
  public void verify2() throws Exception {
	  driver.findElement(By.xpath("//*[@id=\'main-nav\']/a[4]/span")).click();
		driver.findElement(By.xpath("//*[@id=\'dashboard-toolbar\']/div[2]/div/a/button")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[1]/div[1]/div/div/div/input")).sendKeys("ValueLabs");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[2]/div/div/div/input")).sendKeys("www.valuelabs.com");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[3]/div/div/div/div[1]/div/input")).sendKeys("HITEC City, Hyderabad");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[3]/div/div/div/div[2]/div/input")).sendKeys("Hyderabad");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[3]/div/div/div/div[3]/div/input")).sendKeys("Andhra Pradesh");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[3]/div/div/div/div[4]/div/input")).sendKeys("500081");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[3]/div/div/div/div[5]/div/input")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[3]/div/div/div/div[5]/div/div[2]/div[100]/span")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[4]/div[1]/div/div/div/div[1]/div[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[4]/div[1]/div/div/div/div[1]/div[2]/div[100]/span")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[4]/div[1]/div/div/div/div[2]/input")).sendKeys("+918745985652");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[4]/div[1]/div/div/div/div[3]/input")).sendKeys("+918745784585");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[4]/div[2]/div/label[2]/div/input")).sendKeys("selenium");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[4]/div[2]/div/label[2]/div/div[2]/div")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[4]/div[2]/div/label[2]/div/input")).sendKeys("Tester");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[4]/div[2]/div/label[2]/div/div[2]")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[6]/div/div/textarea")).sendKeys("Technology, innovation and problem solving � that�s where we play. We specialize in digital enablement, software product development and data technology. ");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[7]/div[1]/div/div/div/div[1]/div[1]")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[7]/div[1]/div/div/div/div[1]/div[2]/div[3]/span")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[7]/div[1]/div/div/div/div[2]/input")).sendKeys("https://in.linkedin.com/company/valuelabs");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[7]/div[2]/div/div/input")).sendKeys("Software Services");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[8]/div[1]/div/div/input")).sendKeys("5001-10,000 employees");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[8]/div[2]/div/div/input")).sendKeys("N/A");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[9]/div[1]/div/div/input")).sendKeys("$217M");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[9]/div[2]/div/div/div[1]")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[9]/div[2]/div/div/div[2]/div[3]")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[10]/div[1]/div/div/div[1]")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[10]/div[1]/div/div/div[2]/div[2]")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[10]/div[2]/div/div/div[1]")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[10]/div[2]/div/div/div[2]/div[6]")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[11]/div[1]/div/div/div[1]")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[11]/div[1]/div/div/div[2]/div[2]")).click();
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[11]/div[2]/div/div/input")).sendKeys("N/A");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[12]/div[1]/div/div/input")).sendKeys("N/A");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div[2]/div[2]/div/div[2]/form/div[12]/div[2]/div/div/div/input")).sendKeys("NA");
		Thread.sleep(1000);
  }
  
  @Test(description = "Verify Data Save functionality")
  public void verify3() throws Exception {
	  	driver.findElement(By.xpath("//*[@id=\"dashboard-toolbar\"]/div[2]/div/button[2]")).click();
		Thread.sleep(8000);
  }
  
  @Test(description = "Verify Logout functionality")
  public void verify4() {
	  	driver.findElement(By.xpath("//*[@id=\'top-header-menu\']/div[2]/div[2]/div")).click();
		driver.findElement(By.xpath("//*[@id=\'top-header-menu\']/div[2]/div[2]/div/div[2]/a[4]/span")).click();
  }
  
  @BeforeTest
  public void beforeTest() {
	  	System.setProperty("webdriver.chrome.driver","D:\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://ui.freecrm.com");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  	Thread.sleep(2000);
		driver.quit();
  }

}
