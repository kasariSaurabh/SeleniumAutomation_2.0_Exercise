package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Selenium4Links_WithLog4j {
	
	WebDriver driver;
	Logger log = Logger.getLogger(Selenium4Links_WithLog4j.class);
  
  @Test // Test Scenario
  public void verifyMFAQs() {
	  try {
	  driver.findElement(By.linkText("Manual FAQsaa")).click();
	  log.info("Click on Manual FAQs");
	  }catch(Exception e){
		  log.error("Unable to click on Manual FAQs");
	  }
  }
  
  @Test
  public void verifySFAQs() {
	  try {
	  driver.findElement(By.linkText("Selenium FAQs")).click();
	  log.info("Click on Selenium FAQs");
	  }catch(Exception e) {
		  log.error("Unable to click on Selenium FAQs");
	  }
  }
  
  @Test
  public void verifyCFAQs() {
	  try {
	  driver.findElement(By.linkText("Core Java FAQs")).click();
	  log.info("Click on Core Java FAQs");
	  }catch(Exception e) {
		  log.error("Unable to click on Core Java FAQs");
	  }
  }
  
  @BeforeTest
  public void beforeTest() {
	  try {
	  System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
	  driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  driver.get("http://selenium4testing.com");
	  log.info("Opened the URL");
	  driver.findElement(By.id("closediv")).click();
	  }catch(Exception e) {
		  log.error("Unable to Open Browser and URL");
	  }
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(2000);
	  driver.quit();
  }

}
