package testNG;

import org.testng.annotations.Test;

import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Selenium4links_Parameter {
	
	WebDriver driver;
	
	public void click(String str) {
		driver.findElement(By.linkText(str)).click();
	}
	
  @Test(description = "verify links functionality")
  public void verifyFAQs() throws Exception {
	  	
	  	click("Manual FAQs");
		Thread.sleep(1000);
		click("Selenium FAQs");
		Thread.sleep(1000);
		click("Core Java FAQs");
		Thread.sleep(1000);
		click("Downloads");
	  
  }
  
  @BeforeTest
  public void beforeTest() {
	  	System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://selenium4testing.com");
		driver.findElement(By.id("closediv")).click();
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(1000);
	  driver.quit();
  }

}
