package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class ArraysEx {
  @Test
  public void test1() {
	// String str="suresh"; 
	//  String s=new String();
	//	  String[] str2 = new String[100];
	//	  int[] k;
	//	  char[] c;
	//    Object[] o;
	//	  String[] s1;
		  
		  String[] str1 = {"suresh", "mahesh", "Raj", "ram", "Sita"};
		  System.out.println(str1.length);
		  
		  //To print in normal order
		  for(int i=0; i<str1.length; i++){
			  System.out.println(str1[i]);  
		  }
		  
		  //To print in reverse order
		  for(int i=str1.length-1; i>=0; i--)
		  {
			  System.out.println(str1[i]);
		  }
  }
  
  @Test
  public void test2() {
	  String str="one,two,three,four,five";
	  String[] s = str.split(",");
	  System.out.println(s.length);
	  for(int i=0 ; i<s.length; i++){
		  if(s[i].equalsIgnoreCase("three"))
		  {
			 String str1=s[i] ;
		  System.out.println(str1);
		  }
	  }
  }
  @Test
  public void test3() {
	  String str1= "";
	  String str="We Love Selenium";
	  String[] s = str.split(" ");
	  System.out.println(s.length);
	  
	  for(int i=0; i<s.length; i++) {
		  System.out.println(s[i]);
		  
		  if(s[i].equalsIgnoreCase("Selenium")) {
			 
			  str1=s[i];
			  System.out.println(str1);
		  } 
		  for(int j=str1.length()-1; j>=0; j--) {
			  
			  System.out.println(str1.charAt(j));
		  }
	  }
	  
  }  
  
  
  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

}
