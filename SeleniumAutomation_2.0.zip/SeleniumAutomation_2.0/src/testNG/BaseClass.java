package testNG;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class BaseClass {
	String str;
	public WebDriver driver;
	
	public void enterText(String loc, String data) {
		  driver.findElement(By.xpath(loc)).sendKeys(data); 
	}
	public void click(String loc){
		driver.findElement(By.xpath(loc)).click();
	}
	public void clickLink(String linkname) {
		driver.findElement(By.linkText(linkname)).click();
	}
	public void select(String loc, String data) {
		new Select(driver.findElement(By.xpath(loc))).selectByVisibleText(data);
	}
	public void enterArea(String loc, String data) {
		driver.findElement(By.xpath(loc)).sendKeys(data);
	}
	
	public void alert_OK(){
		//String str=null;
		str=driver.switchTo().alert().getText();
		System.out.println(str);
		driver.switchTo().alert().accept(); //To click ok
	}
	
	public void takeScreenShot(String str) throws Exception{
		SimpleDateFormat df= new SimpleDateFormat("yyyy MMM dd hh mm ss a");
		Date d = new Date();
		String time = df.format(d);
		System.out.println(time);
		File f= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(f, new File("D:\\lib\\Image\\"+str+time+".png"));
	}
	

}
