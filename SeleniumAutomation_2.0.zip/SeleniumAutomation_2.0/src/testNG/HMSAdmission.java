package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class HMSAdmission extends BaseClass {
	
	@Test(description = "verify login functionality")
	public void test1() {
		  enterText("//input[@name ='username']","admin");
	  	  enterText("//input[@name ='password']","admin");
	  	  click("//input[@name ='submit']");  
  }
	
	@Test(description = "verify ADT functionality")
	public void test2() {
		clickLink("ADT");
		clickLink("Admission");
	}
  
	@Test(description = "verify fill admission form functionality")
	public void test3() {
		enterText("//input[@name='PNT_ID']", "322428");
		enterText("//input[@name='BOOKING_ID']", "Venktesh Babu Reddy");
		enterText("//input[@name = 'MR_NO']", "PR5101345276");
		enterText("//input[@name = 'REQ_ID']", "005623");
		
	}
	@Test(description = "verify fill admission details functionality")
	public void test4() {
		select("//select[@name = 'ADM_TPYE']", "Illness");
		enterText("//input[@name = 'EXP_DATE']", "20-08-2019");
		select("//select[@name = 'PNT_CLASS']", "1st Class");
		enterText("//input[@name = 'EXP_STAY_DATE']", "10");
		select("//select[@name = 'EXP_STAY_FORMAT']", "Days");
		select("//select[@name = 'INSU_PLAN']", "Yes");
		enterText("//input[@name = 'EXP_DISCHARGE_DATE']", "30-08-2019");
		select("//select[@name = 'ADM_SOURSE']", "1st Class");
		select("//select[@name = 'HOSPITAL_SERVICES']", "Diagnastic Services");
		select("//select[@name = 'DOC_NAME']", "Sai");
		select("//select[@name = 'HOSPITAL_SUB_SERVICES']", "X-Ray");
		select("//select[@name = 'DOC_SPL']", "cordialagist");
		enterText("//input[@name = 'PROVI_DIAGNOS']", "Test Report");
		enterText("//input[@name = 'PRMRY_CONSULT']", "sharath");
		enterText("//input[@name = 'CHIEF_COMPLAINT']", "none");
		select("//select[@name = 'ADD_DOC_SPL']", "Cordialagist");
		enterArea("//textarea[@name = 'NOTES']", "None");
		select("//select[@name = 'ADD_DOC_NAME']", "sharath");
		select("//select[@name = 'SC_PROOF']", "Yes");	
	}
	
	@Test(description = "verify Episode details functionality")
	public void test5() {
		enterText("//input[@name = 'EPISODE_NO']", "368547");
		enterText("//input[@name = 'ENCOUNTER_NO']", "356241");
		enterText("//input[@name = 'EPISODE_DEC']", "none");
	}
	@Test(description = "verify Assign Bed details functionality")
	public void test6() {
		select("//select[@name = 'BED_CLASS']", "A/C");
		select("//select[@name = 'ADM_BED_CLASS']", "A/C");
		select("//select[@name = 'BED_NUM']", "BED-2");
		select("//select[@name = 'NURSING_STATION']", "Jhansi Laxmi");
		select("//select[@name = 'WARD_NUM']", "9");
	}
	@Test(description = "verify Add. details functionality")
	public void test7() {
		select("//select[@name = 'AMBULATORY_STATUS']", "Ambulance");
		select("//select[@name = 'MODE_ARRIVAL']", "Ambulance");
	}
	@Test(description = "verify Add. details functionality")
	public void test8() {
		enterArea("//textarea[@name = 'PNT_VALUBLES']", "None");
		select("//select[@name = 'CAPTURED_BY']", "Admin");
		enterText("//input[@name = 'CAPTURED_DATE']", "02-09-2019");
		
	}
	@Test(description = "verify Add. details functionality")
	public void test9() throws Exception {
		click("//input[@name = 'submit']");
		Thread.sleep(4000);
		alert_OK();
		Thread.sleep(4000);
	}
	
	
  @BeforeTest
  public void beforeTest() {
	  	System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global wait
		driver.get("http://selenium4testing.com/hms");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(2000);
	  driver.quit();
  }

}
