package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class CaptureScreenShot {
	
	WebDriver driver;
	
	public void takeScreenShot(String str) throws Exception{
		SimpleDateFormat df= new SimpleDateFormat("yyyy MMM dd hh mm ss a");
		Date d = new Date();
		String time = df.format(d);
		System.out.println(time);
		File f= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(f, new File("D:\\lib\\Image\\"+str+time+".png"));
	}
	
  @Test(description = "Verify ScreenShot functionality")
  public void verify() throws Exception {
	  driver.findElement(By.linkText("Manual FAQs")).click();
	  takeScreenShot("MFAQs");
	  
	  driver.findElement(By.linkText("Selenium FAQs")).click();
	  takeScreenShot("SFAQs");
	  
	  driver.findElement(By.linkText("Core Java FAQs")).click();
	  takeScreenShot("CFAQs");
  }
  
  @BeforeTest
  public void beforeTest() {
	  	System.setProperty("webdriver.chrome.driver", "D://lib//chromedriver.exe");
	  	driver = new ChromeDriver();
		driver.manage().window().maximize();
	//	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://selenium4testing.com");
		driver.findElement(By.id("closediv")).click();
  }

  @AfterTest
  public void afterTest() {
	  driver.quit();
  }

}
