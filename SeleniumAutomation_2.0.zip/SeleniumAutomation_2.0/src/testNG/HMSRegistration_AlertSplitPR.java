package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class HMSRegistration_AlertSplitPR extends BaseClass {
		  
	String str1;
	
		  @Test(description = "verify login functionality")
		  public void test1() throws Exception {
			  	  enterText("//input[@name ='username']","admin");
			  	  enterText("//input[@name ='password']","admin");
			  	  click("//input[@name ='submit']");
			  	  
		  }
		  @Test(description = "verify click registration functionality")
		  public void test2() throws Exception {
			  	 clickLink("Registration");
			  	
		  }
		  @Test(description = "verify fill registration form functionality")
		  public void test3() throws Exception {
			  select("//select[@name = 'PATIENT_CAT']", "Insurance");
			  select("//select[@name = 'RELATION']", "Father");
			  select("//select[@name = 'TITLE']", "Mr.");
			  enterText("//input[@name = 'MOTHER_NAME']", "Lakshmi");
			  enterText("//input[@name = 'PNT_NAME']", "Venktesh");
			  enterText("//input[@name = 'MIDDLE_NAME']", "Babu");
			  enterText("//input[@name = 'LAST_NAME']", "Reddy");
			  enterText("//input[@name='image']", "D:\\lib\\Image\\pic.jpg");
			  Thread.sleep(2000);
			  select("//select[@name = 'PAT_IDENTITY']", "AAdhar Card");
			  enterText("//input[@name = 'PAT_IDENTITY_PROOF']", "000079658985");
			  enterText("//input[@name = 'DOB']", "01-09-2019");
			  Thread.sleep(2000);
			  select("//select[@name = 'NATIONALITY']", "Indian");
			  enterText("//input[@name = 'AGE']","25");
			  select("//select[@name = 'IS_MLC']", "Yes");
			  select("//select[@name = 'SEX']", "Male");
			  select("//select[@name = 'EDUCATION']", "B.Sc");
			  select("//select[@name = 'MTRL_STATUS']", "Single");
			  select("//select[@name = 'OCCUPATION']", "Employee");
			  select("//select[@name = 'RELIGION']", "Hindu");
			  select("//select[@name = 'BLOOD_GRP_CODE']", "A+");
			  select("//select[@name = 'PLANGUAGE']", "Tamil");
			  select("//select[@name = 'CITIZENSHIP']", "Indian");
			  select("//select[@name = 'SC_PROOF']", "No");
			 
		  }
		  
		  @Test(description = "verify address functionality")
		  public void test4() throws Exception {
			  enterText("//input[@name = 'ADDRESS1']", "Ameerpet, Hyderabad");
			  enterText("//input[@name = 'ADDRESS2']", "SR Nagar, Hyderabad");
			  enterText("//input[@name = 'MOBILE_NO']", "0000035624");
			  enterText("//input[@name = 'EMAIL_ID']", "venktesh01@gmail.com");
			  enterText("//input[@name = 'ZIP']", "500031");
			  select("//select[@name = 'COUNTRY_CODE']", "India");
			  click("//input[@name = 'submit']");
			  Thread.sleep(3000);
		  }
		  
		  @Test(description = "verify Alert functionality")
		  public void test5() {
			  alert_OK();  
		  }
	
	@Test(description = "verify split patient ID from popup window")
  public void test6() {
		
		String[] s = str.split(" ");
		System.out.println(s.length);
		for(int i=0; i<s.length; i++) {
			if(s[i].contains("PR")) {
				
				str1 = s[i];
				System.out.println("\n");
				System.out.println(s[i]);
			}
		}	
		
	}
	
	@Test(description = "verify search patient ID and print all information on console")
	public void test7() {
		
		driver.findElement(By.linkText("Search Registration")).click();
		driver.findElement(By.name("search")).sendKeys(str1);
		driver.findElement(By.name("submit")).click();
		String str2;
		str2 = driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[2]/form/div/table[2]")).getText();
		System.out.println("\n");
		System.out.println(str2);
		String str3;
		str3 = driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[2]/form/div/table[3]")).getText();
		System.out.println(str3);
		System.out.println("\n");
  }
	
  @BeforeTest
  public void beforeTest() throws Exception {
	  	System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global wait
		driver.get("http://selenium4testing.com/hms");
		Thread.sleep(2000);
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(3000);
	  driver.quit();
  }

}
