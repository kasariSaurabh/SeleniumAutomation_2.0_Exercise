package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class FrameHandling {
	WebDriver driver;
  @Test
  public void f() {
	  
	  driver.switchTo().frame(driver.findElement(By.xpath("//*[@id=\'moneyiframe\']")));
	  //driver.switchTo().frame(driver.findElement(By.id("moneyiframe"))); 		// This is used by ID
	  driver.findElement(By.id("query")).sendKeys("Automation Test");
	  driver.switchTo().defaultContent();
	  driver.findElement(By.id("srchword")).sendKeys("Testing");
	 
  }
  @BeforeTest
  public void beforeTest() {
	  	System.setProperty("webdriver.chrome.driver", "D://lib//chromedriver.exe");
	  	driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.rediff.com/");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(2000);
	  driver.quit();
  }

}
