package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
public class WebTable_Spicejet {
	
	WebDriver driver;
	
	@Test
	public void test1() {
		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
		String str;
		str= driver.findElement(By.xpath("//*[@id=\'glsctl00_mainContent_ddl_originStation1_CTNR\']")).getText();
		//System.out.println(str);
		String[] s = str.split("\n");
		System.out.println(s.length);
		for(int i=0; i<s.length; i++) {
	
			if(s[i].contains("Hyderabad (HYD)")) {
				
				System.out.println(s[i]);
				driver.findElement(By.linkText(s[i])).click();
			}
		}
  }
	                                      
	@Test()
	public void test2() {
		String str;
		str = driver.findElement(By.id("glsctl00_mainContent_ddl_destinationStation1_CTNR")).getText();
		//System.out.println(str);
		String[] s = str.split("\n");
		System.out.println(s.length);
		int n=0;
		for(int i=0; i<s.length; i++) {
			
			System.out.println(s[i]);
			if(s[i].contains("Hyderabad (HYD)")) {
				System.out.println("Hyderabad City is Available");
				n=n+1;
			}
		}	
			if(n==0) {
				System.out.println("Hyderabad City is not Available");
			}
	}
		
  @BeforeTest
  public void beforeTest() {
	  	System.setProperty("webdriver.chrome.driver", "D://lib//chromedriver.exe");
	  	driver = new ChromeDriver();
	  	driver.manage().window().maximize();
	  	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  	driver.get("https://www.spicejet.com/");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(5000);
	  driver.quit();
  }

}
