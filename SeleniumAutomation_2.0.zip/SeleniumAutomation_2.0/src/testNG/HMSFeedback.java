package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

@Test
public class HMSFeedback extends BaseClass {
	
  public void test1() {
	  enterText("//input[@name ='username']","admin");
	  enterText("//input[@name ='password']","admin");
	  click("//input[@name ='submit']");  
  }
	
  public void test2() throws Exception {
	  clickLink("Feedback");
	  Set<String> str = driver.getWindowHandles();
	  System.out.println("The Window are: "+str);
	  Object[] s = str.toArray();
	  driver.switchTo().window(s[1].toString());
	  driver.findElement(By.id("name")).sendKeys("Venktesh Babu Reddy");
	  driver.findElement(By.id("email")).sendKeys("venktesh01@gmail.com");
	  new Select(driver.findElement(By.id("car"))).selectByVisibleText("Mercedes");
	  driver.findElement(By.name("radio")).click();
	  driver.findElement(By.xpath("/html/body/div[2]/div/div/form/ul/li[5]/label/input")).click();
	  driver.findElement(By.xpath("/html/body/div[2]/div/div/form/ul/li[6]/input")).sendKeys("D:\\lib\\Image\\pic.jpg");
	  driver.findElement(By.id("message")).sendKeys("None");
	  driver.findElement(By.xpath("/html/body/div[2]/div/div/form/p/button[1]")).click();
	  Thread.sleep(2000);
	  driver.close();
	  Thread.sleep(2000);
	  driver.switchTo().window(s[0].toString());
	  driver.findElement(By.linkText("ADT")).click();
	  driver.findElement(By.linkText("Logout")).click();
	  Thread.sleep(2000);
  }
  
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global wait
	  driver.get("http://selenium4testing.com/hms");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(2000);
	  driver.quit();
  }

}
