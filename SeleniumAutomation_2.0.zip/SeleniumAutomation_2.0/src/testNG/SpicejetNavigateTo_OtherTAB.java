package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class SpicejetNavigateTo_OtherTAB {
	WebDriver driver;
  @Test
  public void f() throws Exception {
	  driver.findElement(By.xpath("//*[@id=\'traveller-home\']/div[2]/div/div[2]/a[1]/span[1]")).click();
	  Set<String> str = driver.getWindowHandles();
	  System.out.println("The Tab are :"+str);
	  Object[] s = str.toArray();
	  driver.switchTo().window(s[1].toString());
	  driver.findElement(By.linkText("DEALS")).click();
	  Thread.sleep(2000);
	  driver.close();
	  driver.switchTo().window(s[0].toString());
	  driver.findElement(By.linkText("Hotels")).click();
	  Thread.sleep(2000);
	  
  }
  @BeforeTest
  public void beforeTest() {
	  	System.setProperty("webdriver.chrome.driver", "D://lib//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://www.spicejet.com/");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(2000);
	  driver.quit();
  }

}
