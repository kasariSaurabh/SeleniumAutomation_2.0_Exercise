package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class FreeCRMLogin {
	
	WebDriver driver;
	
  @Test(description = "Varify login functionality")
  public void login() throws Exception {
	  	driver.findElement(By.xpath("//*[@id=\'ui\']/div/div/form/div/div[1]/div/input")).sendKeys("nag010683@gmail.com");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div/form/div/div[2]/div/input")).sendKeys("Nagesh@123");
		driver.findElement(By.xpath("//*[@id=\'ui\']/div/div/form/div/div[3]")).click();
  }
  
  @Test(description = "Varify logout functionality")
  public void logout() {
	  	driver.findElement(By.xpath("//*[@id=\'top-header-menu\']/div[2]/div[2]/div")).click();
		driver.findElement(By.xpath("//*[@id=\'top-header-menu\']/div[2]/div[2]/div/div[2]/a[4]/span")).click();
	
  }
  
  @BeforeTest
  public void beforeTest() {
	  	System.setProperty("webdriver.chrome.driver", "D://lib//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://ui.freecrm.com");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(2000);
	  driver.quit();
  }

}
