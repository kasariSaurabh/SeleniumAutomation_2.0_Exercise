package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class PrintTextboxLocators {
	WebDriver driver;
	public void login(){
		driver.findElement(By.name("username")).sendKeys("admin");
		driver.findElement(By.name("password")).sendKeys("admin");
		driver.findElement(By.name("submit")).click();
	}
	public void registration(){
		driver.findElement(By.linkText("Registration")).click();
	}
	
	@Test
	  public void f1() {
		  login();
		  registration();
		  List<WebElement> str = driver.findElements(By.tagName("input"));
		  System.out.println(str.size());
		  for(int i=0; i<str.size(); i++) {
			  System.out.println("TextBox locator is : "+ str.get(i).getAttribute("name"));
		  }
		  System.out.println("\n");
		  
	  }
	
  @Test
  public void f2() {
	  //login();
	  //registration();
	  List<WebElement> str = driver.findElements(By.tagName("input"));
	  System.out.println(str.size());
	  for(int i=0; i<str.size(); i++) {

		  if(!str.get(i).getAttribute("type").contentEquals("text")) {
			  System.out.println("Textbox locator is :"+str.get(i).getAttribute("type"));
		  }
	  }
	  
  }
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global wait
	  driver.get("http://selenium4testing.com/hms");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(3000);
	  driver.quit();
  }

}
