package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class WebTable_GoogleSearch {
  
	WebDriver driver;
	
	@Test
  public void f() {
	  driver.findElement(By.name("q")).sendKeys("selenium nagesh");
	  String str;
	  str = driver.findElement(By.xpath("//*[@id=\'tsf\']/div[2]/div[1]/div[2]/div[2]")).getText();
	  System.out.println(str);
	  System.out.println("\n");
	  String[] s = str.split("\n");
	  System.out.println(s.length);
	  for(int i=0; i<s.length; i++) {
		  if(s[i].contains("selenium by nagesh k")) {
			  System.out.println(s[i]);
			  driver.findElement(By.name("q")).clear();
			  driver.findElement(By.name("q")).sendKeys(s[i]);
		  }
	  }
  }
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global wait
	  driver.get("http://google.co.in");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(5000);
	  driver.quit();
  }

}
