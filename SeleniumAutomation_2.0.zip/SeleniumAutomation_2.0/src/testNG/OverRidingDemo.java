package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;

public class OverRidingDemo extends GoogleLinks {
	
  public void click(String str) throws Exception{
	driver.findElement(By.xpath(str)).click();
	driver.navigate().to("https://accounts.google.com/ServiceLogin/identifier?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F%3Ftab%3Dwm%26ogbl&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=AddSession");
	driver.findElement(By.name("identifier")).sendKeys("testingse2@gmail.com");
	driver.findElement(By.xpath("//*[@id='identifierNext']/span/span")).click();
	driver.findElement(By.name("password")).sendKeys("Selenium5");
	Thread.sleep(2000);
	driver.findElement(By.xpath("//*[@id='passwordNext']/span/span")).click();	
	s="Nagesh";
	System.out.println(s);
	
  }
	
  @Test
  public void f() throws Exception{
	  
	  super.click("//a[text()='Gmail']");
	  
  }
  
  @BeforeTest
  public void beforeTest1() {
}

  @AfterTest
  public void afterTest1() {
  }

}
