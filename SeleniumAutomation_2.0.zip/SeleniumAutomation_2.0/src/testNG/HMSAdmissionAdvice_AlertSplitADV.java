package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class HMSAdmissionAdvice_AlertSplitADV extends BaseClass {
	String str1;
	
	@Test(description = "verify login functionality")
	public void test1() {
		  enterText("//input[@name ='username']","admin");
	  	  enterText("//input[@name ='password']","admin");
	  	  click("//input[@name ='submit']");  
  }
	
	@Test(description = "verify ADT functionality")
	public void test2() {
		clickLink("ADT");
		clickLink("Admission Advice");
	}
	
	
  @Test(description = "Verify admission advice functionality")
  public void test3() {
	  enterText("//input[@name = 'MR_NO']", "PR5101345276");
	  enterText("//input[@name = 'PNT_NAME']", "Venktesh Babu Reddy");
	  select("//select[@name = 'GENDER']", "Male");
	  select("//select[@name = 'DOC_NAME']", "Sai");
	  select("//select[@name = 'DOC_SPL']", "cordialagist");
	  select("//select[@name = 'ADMISSION_TYPE']", "In Patient");
	  select("//select[@name = 'PATIENT_CAT']", "Pay Patient");
	  select("//select[@name = 'HOSPITAL_SERVICES']", "Consultation");
	  enterText("//input[@name = 'PROVI_DIOGNOS']", "Test Report");
	  enterText("//input[@name = 'EXP_DATE']", "10-09-2019");
	  enterText("//input[@name = 'EXP_LENGTH']", "10");
	  select("//select[@name = 'EXP_FORMAT']", "Days");
	  select("//select[@name = 'BED_REQ']", "Yes");
	  enterArea("//textarea[@name = 'REMARKS']", "none");
  }
  
  @Test(description = "Verify submit functionality")
  public void test4() throws Exception {
	  click("//input[@name = 'submit']");
	  Thread.sleep(3000);
  }
  
  @Test(description = "verify Alert functionality")
  public void test5() {
	  alert_OK();  
  }
  
  @Test(description = "verify Advice Number functionality")
  public void test6() {
	  String[] s = str.split(" ");
		System.out.println(s.length);
		for(int i=0; i<s.length; i++) {
			if(s[i].contains("ADV")) {
				
				str1 = s[i];
				System.out.println("\n");
				System.out.println(s[i]);
			}
		}	
  }
  
  @Test(description = "verify Search Advice Number functionality")
  public void test7() throws Exception {
	  driver.findElement(By.linkText("Admission Advice List")).click();
	  driver.findElement(By.name("search")).sendKeys(str1);
	  driver.findElement(By.name("submit")).click();
	  Thread.sleep(3000);
	  String str2;
	  str2 = driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/table[1]")).getText();
	  System.out.println("\n");
	  System.out.println(str2);
	  String str3;
	  str3 = driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/table[2]")).getText();
	  System.out.println(str3);
	  System.out.println("\n");
  }
  
  @BeforeTest
  public void beforeTest() throws Exception {
	  System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global wait
	  driver.get("http://selenium4testing.com/hms");
	  Thread.sleep(2000);
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(2000);
	  driver.quit();
  }

}
