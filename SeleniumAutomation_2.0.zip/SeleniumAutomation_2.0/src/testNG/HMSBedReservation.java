package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class HMSBedReservation extends BaseClass {
	
	@Test(description = "verify login functionality")
	public void test1() {
		  enterText("//input[@name ='username']","admin");
	  	  enterText("//input[@name ='password']","admin");
	  	  click("//input[@name ='submit']");  
  }
	
	@Test(description = "verify ADT hierarchy functionality")
	public void test2() {
		//clickLink("ADT");
		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[2]/div")).click();
		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[2]/ul/li[3]/div")).click();
		//clickLink("Bed Details");
		clickLink("Bed Reservation");
	}	
  @Test(description = "verify fill bed reservation functionality")
  public void test3() {
	  enterText("//input[@name = 'PNT_ID']", "322428");
	  enterText("//input[@name = 'MR_NO']", "PR5101345276");
	  enterText("//input[@name = 'REQ_ID']", "005623");  
  }
  
  @Test(description = "verify fill admission details functionality")
  public void test4() {
	  select("//select[@name = 'ADD_DOC_NAME']", "sharath");
	  select("//select[@name = 'DOC_SPL']", "cordialagist");
	  enterText("//input[@name = 'EXP_DATE']", "12-09-2019");
	  enterText("//input[@name = 'EXP_STAY_DATE']", "10");
	  select("//select[@name = 'EXP_STAY_FORMAT']", "Days");
  }
  
  @Test(description = "verify fill assign bed functionality")
  public void test5() throws Exception {
	  select("//select[@name = 'BED_NUM']", "BED-2");
	  enterText("//input[@name = 'FROM_DATE']", "02-09-2019");
	  select("//select[@name = 'NURSING_STATION']", "Rani");
	  select("//select[@name = 'WARD']", "9");
	  enterText("//input[@name = 'REASON']", "Treatment");
	  enterArea("//textarea[@name = 'NOTES']", "none");
	  enterText("//input[@name = 'REFERRED_BY']", "Sai");
	  click("//input[@name = 'submit']");
	  Thread.sleep(3000);
  }
  
  @Test(description = "verify Alert functionality")
  public void test6() {
	  alert_OK();  
  }
    
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global wait
	  driver.get("http://selenium4testing.com/hms");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(2000);
	  driver.quit();
  }

}
