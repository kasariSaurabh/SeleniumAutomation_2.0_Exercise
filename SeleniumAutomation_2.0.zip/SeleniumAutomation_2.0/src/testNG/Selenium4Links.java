package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Selenium4Links {
	
	WebDriver driver;
	 
  @Test // Test Scenario
  public void verifyMFAQs() {
	  driver.findElement(By.linkText("Manual FAQs")).click();
  }
  
  @Test
  public void verifySFAQs() {
	  driver.findElement(By.linkText("Selenium FAQs")).click();
  }
  
  @Test
  public void verifyCFAQs() {
	  driver.findElement(By.linkText("Core Java FAQs")).click();
  }
  
  @BeforeTest // Before Condition 
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
	  driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  driver.get("http://selenium4testing.com");
	  driver.findElement(By.id("closediv")).click();
	
  }

  @AfterTest // Post Condition
  public void afterTest() throws Exception {
	  Thread.sleep(2000);
	  driver.quit();
	 
  }

}
