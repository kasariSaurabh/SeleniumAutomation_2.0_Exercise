package testNG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class GoogleLinks {
  
	public String username = "nagesh";
	protected String password = "nagesh";
	String s;
	public WebDriver driver;
 	public void click(String str) throws Exception{
 		 driver.findElement(By.xpath(str)).click();
 	}
 	
	  /*@Test(description = "Verify Hindi link")
	  public void test1() throws Exception {
		  click("//*[@id=\"SIvCob\"]/a[1]");
		  Thread.sleep(2000);
		  driver.navigate().back();
		  Thread.sleep(2000);
	  }
	  
	  @Test(description = "Verify Bengali link")
	  public void test2() throws Exception {
		  click("//*[@id='SIvCob']/a[2]");
		  Thread.sleep(2000);
		  driver.navigate().back();
		  Thread.sleep(2000);
	  }
	  @Test(description = "Verify Telugu link")
	  public void test3() throws Exception {
		  click("//*[@id=\"SIvCob\"]/a[3]");
		  Thread.sleep(2000);
		  driver.navigate().back(); // To go back page
		//  driver.navigate().forward(); // To go front page
		  Thread.sleep(2000);
	  }*/
	
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global wait
	  driver.get("http://google.co.in");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(2000);
	  driver.quit();
  }
  
  	

}
