package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class PrintDropdown_DefaultValue {
  
	WebDriver driver;
	@Test
  public void f() {
	String id="ctl00_mainContent_DropDownListCurrency";
	WebElement str = new Select(driver.findElement(By.id(id))).getFirstSelectedOption();
	System.out.println(str.getText());
	if(str.getText().equalsIgnoreCase("INR")){
		System.out.println("Default value is INR");
	}else {
		System.out.println("Default value is not INR");
	}
  }
	
  @BeforeTest
  public void beforeTest() {
	  	System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
	  	driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://spicejet.com");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(3000);
	  driver.quit();
  }

}
