package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.AfterTest;

public class TimeStamp {
  @Test(description = "Verify TimeStamp functionality")
  public void f() {
	  SimpleDateFormat df= new SimpleDateFormat("yyyy MMM dd hh:mm:ss a");
	  Date d =new Date();
	  String time = df.format(d);
	  System.out.println(time);
  }
  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

}
