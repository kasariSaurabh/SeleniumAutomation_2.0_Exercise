package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;

public class ValidationCommands {
	WebDriver driver;
	
  @Test
  public void f() {
	/*  if(driver.findElement(By.name("username")).isDisplayed()){
		  System.out.println("Available");
	  }else {
		  System.out.println("Not Available");
	  }
	  */
	  
	  //if fill "username" wrong then print o/p "Not Available" but through exception
	  //Solve this problem by using try catch block
	  
	/*  try {
		  driver.findElement(By.name("usernamelkj")).isDisplayed();
		  System.out.println("Available");
		  }catch(Exception e){
			  System.out.println("Not Available");
		  }
	  */
	  
	  Assert.assertEquals(driver.findElement(By.name("username")).isDisplayed(), true);
	  Assert.assertEquals(driver.findElement(By.name("username")).isDisplayed(), false);
	  
  }
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global wait
	  driver.get("http://selenium4testing.com/hms");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(3000);
	  driver.quit();
  }

}
