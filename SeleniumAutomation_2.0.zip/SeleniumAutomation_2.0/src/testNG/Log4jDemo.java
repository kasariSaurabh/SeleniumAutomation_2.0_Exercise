package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.apache.log4j.Logger;
import org.testng.annotations.AfterTest;

public class Log4jDemo {
  
	Logger log = Logger.getLogger(Log4jDemo.class);
	@Test
  public void f() {
	  
	  log.debug("Debug msg");
	  log.info("information");
	  log.warn("warn msg");
	  log.error("error msg");
	  log.fatal("fatal mag");
	  
  }
  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

}
