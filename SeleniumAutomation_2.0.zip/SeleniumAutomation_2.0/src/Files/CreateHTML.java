package Files;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import org.testng.annotations.Test;

public class CreateHTML {
  @Test
  public void f() throws Exception {
	  
	  File f = new File(".\\TestReports\\LoginResult.html");
	  FileWriter fw = new FileWriter(f);
	  BufferedWriter bw = new BufferedWriter(fw);
	  bw.write("<html>");
	  bw.write("<body>");
	  bw.write("<table cellspacing='3' cellpading ='2' border ='3'>");
	  bw.write("<tbody>");
	  bw.write("<tr>");
	  		bw.write("<th>");
	  		bw.write("<font size='5' color = 'green'>");
	  		bw.write("Username");
	  		bw.write("</font>");
	  		bw.write("</th>");
	  		
	  		bw.write("<td><font size='5' color = 'red'>Password</font></td>");
	  		
	  		bw.write("<td><font size='5' color ='yellow'>");
			bw.write("Result");
			bw.write("</font></td>");
			
	  bw.write("</tr>");
	  bw.write("</tbody>");
	  bw.write("</table>");
	  bw.write("</body>");
	  bw.write("</html>");
	  bw.close();
	  
  }
}
