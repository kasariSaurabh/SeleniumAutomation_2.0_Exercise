package Files;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.AfterTest;

public class ReadData_Excel {
  @Test
  public void f() throws IOException {
	  
	FileInputStream fi = new FileInputStream("D:\\SeleniumWebdriver\\SeleniumAutomation_2.0\\TestData\\LoginData.xlsx");
	Workbook w = new XSSFWorkbook(fi);
	Sheet s = w.getSheet("Sheet1");
	Row r = s.getRow(0);
	Cell c = r.getCell(0);
	Cell c1 = r.getCell(1);
	System.out.println(c);
	System.out.println(c1);
	
	Row r1 = s.getRow(1);
	Cell c2 = r1.getCell(0);
	Cell c3 = r1.getCell(1);
	System.out.println(c2);
	System.out.println(c3);
	
	Row r2 = s.getRow(2);
	Cell c4 = r2.getCell(0);
	Cell c5 = r2.getCell(1);
	System.out.println(c4);
	System.out.println(c5);
	
	Row r3 = s.getRow(3);
	Cell c6 = r3.getCell(0);
	Cell c7 = r3.getCell(1);
	System.out.println(c6);
	System.out.println(c7);
	System.out.println("\n");
	w.close();
	
  }
  
  @Test
  public void print2columns() throws IOException {
	  FileInputStream fi = new FileInputStream("D:\\SeleniumWebdriver\\SeleniumAutomation_2.0\\TestData\\LoginData.xlsx");
	  Workbook w = new XSSFWorkbook(fi);
	  Sheet s = w.getSheet("Sheet1");
	  
	  for(int i = 0; i<=s.getLastRowNum(); i++ ) {
		  Row r = s.getRow(i);
		  Cell username = r.getCell(0);
		  Cell password = r.getCell(1);
		  System.out.print(username+"    ");
		  System.out.println(password);
	  }
	  w.close(); 
  }
  
  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

}
