package Files;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class HMS_Login {
	WebDriver driver;
	
  @Test(enabled = false)
  public void f1() throws Exception {
	  driver.findElement(By.xpath("//input[@name ='username']")).sendKeys("admin");
	  driver.findElement(By.xpath("//input[@name ='password']")).sendKeys("admin");
	  driver.findElement(By.xpath("//input[@name ='submit']")).click();
	  Thread.sleep(5000);
  }
  
  @Test(enabled = false)
  public void f2() {
	  driver.findElement(By.linkText("Logout")).click();
  }
  
  
  @Test()
  public void f3() throws IOException, Exception {
	  FileInputStream fi = new FileInputStream("D:\\SeleniumWebdriver\\SeleniumAutomation_2.0\\TestData\\RetrieveData.xlsx");
	  Workbook w = new XSSFWorkbook(fi);
	  Sheet s = w.getSheet("Sheet1");
	  Row r = s.getRow(3);
	  Cell username = r.getCell(2);
	  Cell password = r.getCell(3);
	  System.out.println(username);
	  System.out.println(password);
	  
	  driver.findElement(By.xpath("//input[@name ='username']")).sendKeys(username.toString());
	  driver.findElement(By.xpath("//input[@name ='password']")).sendKeys(password.toString());
	  driver.findElement(By.xpath("//input[@name ='submit']")).click();
	  Thread.sleep(2000);
	  try {
		  driver.findElement(By.linkText("Logout")).isDisplayed();
		  driver.findElement(By.linkText("Logout")).click();
		  System.out.println("Pass");
	  }catch(Exception e){
		  System.out.println("Fail");
		  driver.switchTo().alert().accept();
	  }
	  
	  w.close();
  }
  
  
  
  @BeforeTest
  public void beforeTest() {
	  	System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global wait
		driver.get("http://selenium4testing.com/hms");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(2000);
	  driver.quit();
  }

}
