package Files;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class GmailLogin_ReadFromExcelWriteToHTML {
	
	WebDriver driver;
	String result=null;
	
  @Test
  public void f() throws Exception {
	  FileInputStream fi = new FileInputStream(".\\TestData\\TestLoginData.xlsx");
	  Workbook w = new XSSFWorkbook(fi);
	  Sheet s = w.getSheet("Sheet1");
	  File f = new File(".\\TestReports\\GmailLoginResults.html");
	  FileWriter fw = new FileWriter(f);
	  BufferedWriter bw = new BufferedWriter(fw);
	  bw.write("<html>");
	  bw.write("<body>");
	  bw.write("<table cellspacing='3' cellpading ='2' border ='3'>");
	  bw.write("<tbody>");
	  bw.write("<tr>");
	  
	  	bw.write("<th><font size ='6' color ='blue'>");
	  		bw.write("Username");
	  		bw.write("</font></th>");
	
		bw.write("<th><font size ='6' color ='blue'>");
			bw.write("Password");
			bw.write("</font></th>");
	 
		bw.write("<th><font size ='6' color ='blue'>");
			bw.write("Result");
			bw.write("</font></th>");
	  
	  bw.write("</tr>");
	  
	  for (int i = 1; i <= s.getLastRowNum(); i++) {
		  	Row r =s.getRow(i);
			Cell username = r.getCell(0);
			Cell password = r.getCell(1);
			System.out.println(username);
			System.out.println(password);
			
			try {
				
				  driver.findElement(By.name("identifier")).sendKeys(username.toString());
				  driver.findElement(By.xpath("//*[@id='identifierNext']/span/span")).click();
				  Thread.sleep(1000);
				  driver.findElement(By.name("password")).sendKeys(password.toString());
				  driver.findElement(By.xpath("//*[@id='passwordNext']/span/span")).click();
				  Thread.sleep(2000);
				  driver.findElement(By.xpath("/html/body/div[7]/div[3]/div/div[1]/div[4]/header/div[2]/div[3]/div/div[2]/div/a/span")).click();
				  //driver.findElement(By.linkText("Sign out")).isDisplayed();
				  driver.findElement(By.linkText("Sign out")).click();
				  Thread.sleep(1000);
				  driver.findElement(By.xpath("//*[@id=\'view_container\']/div/div/div[2]/div/div/div/form/span/section/div/div/div/div/ul/li[2]/div/div/div[2]")).click();
				  System.out.println("Pass");
				  result="Pass";
			  
			}catch(Exception e) {
				  System.out.println("Fail");
				  driver.findElement(By.xpath("//*[@id=\'identifierId\']")).clear();
				  result="Fail";  
			  }
			
			bw.write("<tr>");
				
				bw.write("<td><font size ='6' color ='blue'>");
				bw.write(username.toString());
				bw.write("</font></td>");
				bw.write("<td><font size ='6' color ='blue'>");
				bw.write(password.toString());
				bw.write("</font></td>");
				bw.write("<td><font size ='6' color ='blue'>");
				bw.write(result);
				bw.write("</font></td>");
			
			bw.write("</tr>");	
			
	  	}
	  	bw.write("</tbody>");
	  	bw.write("</table>");
	  	bw.write("</body>");
	  	bw.write("</html>");
	  	bw.close();
	  	w.close();
	
  }
  
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  driver.get("http://gmail.com");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(6000);
	  driver.quit();
  }

}
