package Files;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.AfterTest;

public class ReadData_Rows_Cols {
  @Test
  public void print2columns() throws IOException {
	  FileInputStream fi = new FileInputStream(".\\TestData\\LoginData.xlsx");
	  Workbook w =new XSSFWorkbook(fi);
	  Sheet s = w.getSheet("Sheet1");
	  for(int i=0; i<=s.getLastRowNum()-1 ; i++) {
		  Row r = s.getRow(i);
		  
		  for(int j=0; j<=r.getLastCellNum()-1 ; j++) {
			  
			  Cell data = r.getCell(j);
			  System.out.println(data);
		  }
		  System.out.print("\n");
	  }
	  w.close();
	  System.out.println("\n");
  
  }
  
  @Test
  public void printTriangle() throws Exception{
	  for(int i=1; i<=5; i++){
		  for(int j=1; j<=i; j++){
			  System.out.print(j);
		  }
		  System.out.println();
	  }
  }
  
  
  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

}
