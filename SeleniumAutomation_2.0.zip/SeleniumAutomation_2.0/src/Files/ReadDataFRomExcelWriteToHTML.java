package Files;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ReadDataFRomExcelWriteToHTML {
	WebDriver driver;
	
  @Test
  public void f() throws Exception {
	  
	  FileInputStream fi = new FileInputStream(".\\TestData\\LoginData.xlsx");
	  Workbook w = new XSSFWorkbook(fi);
	  Sheet s = w.getSheet("Sheet1");
	  File f =new File(".\\TestReports\\LoginResults.html");
	  FileWriter fw = new FileWriter(f);
	  BufferedWriter bw = new BufferedWriter(fw);
	  bw.write("<html>");
	  bw.write("<body>");
	  bw.write("<table cellspacing='3' cellpading ='2' border ='3'>");
	  bw.write("<tbody>");
	  bw.write("<tr>");
	  
	  	bw.write("<th><font size ='6' color ='blue'>");
	  		bw.write("Username");
	  		bw.write("</font></th>");
		
		bw.write("<th><font size ='6' color ='blue'>");
			bw.write("Password");
			bw.write("</font></th>");
		 
		bw.write("<th><font size ='6' color ='blue'>");
			bw.write("Result");
			bw.write("</font></th>");
		  
	  bw.write("</tr>");
	  
	  for (int i = 1; i <= s.getLastRowNum(); i++) {
			Row r =s.getRow(i);
			Cell username = r.getCell(0);
			Cell password = r.getCell(1);
			System.out.println(username);
			System.out.println(password);
			
			bw.write("<tr>");
			
				bw.write("<td><font size ='6' color ='blue'>");
				driver.findElement(By.name("username")).sendKeys(username.toString());
				bw.write(username.toString());
				bw.write("</font></td>");
				
				bw.write("<td><font size ='6' color ='blue'>");
				driver.findElement(By.name("password")).sendKeys(password.toString());
				bw.write(password.toString());
				driver.findElement(By.name("submit")).click();
				bw.write("</font></td>");
			
			
			Thread.sleep(2000);
			try {
				  driver.findElement(By.linkText("Logout")).isDisplayed();
				  driver.findElement(By.linkText("Logout")).click();
				  bw.write("<td><font size ='6' color ='blue'>");
				  System.out.println("Pass");
				  bw.write("Pass");
				  bw.write("</font></td>");
			  
			}catch(Exception e) {
				  bw.write("<td><font size ='6' color ='blue'>");
				  System.out.println("Fail");
				  bw.write("Fail");
				  bw.write("</font></td>");
				  
				//driver.switchTo().alert().accept();
				   
			  }
			
			bw.write("</tr>");
			
	  	}
	  	bw.write("</tbody>");
	  	bw.write("</table>");
	  	bw.write("</body>");
	  	bw.write("</html>");
	  	bw.close();
	  	w.close();
  }


@BeforeTest
	public void beforeTest() {
	  	System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global wait
		driver.get("http://selenium4testing.com/hms");
}

@AfterTest
	public void afterTest() throws Exception {
	  Thread.sleep(2000);
	  driver.quit();
	}

}

