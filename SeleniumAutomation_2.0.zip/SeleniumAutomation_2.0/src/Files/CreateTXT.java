package Files;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import org.testng.annotations.AfterTest;

public class CreateTXT {
  @Test()
  public void createTXT() throws IOException {
		  //File f = new File("D:\\SeleniumWebdriver\\SeleniumAutomation_2.0\\TestReports\\Sample.txt");
		  File f = new File(".\\TestReports\\Sample.txt");
		  FileWriter fw = new FileWriter(f, true);
		  BufferedWriter bw = new BufferedWriter(fw);
		  bw.write("Saurabh");
		  bw.newLine();
		  bw.write("Saurabh1");
		  bw.newLine();
		  bw.write("Saurabh2");
		  bw.newLine();
		  
		  bw.close();	  
  }
  
  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

}
