package Files;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.testng.annotations.AfterTest;

public class ReadTXT {
  
	@Test()
	public void readTXT() throws IOException {
		  	File f = new File("D:\\SeleniumWebdriver\\SeleniumAutomation_2.0\\TestReports\\Sample.txt");
		  	FileReader fr = new FileReader(f);
		  	BufferedReader br = new BufferedReader(fr);
		  	String str = br.readLine();
		  	System.out.println(str);
		  	
		  	while((str = br.readLine())!= null) {
		  		if(str.equalsIgnoreCase("Saurabh2")) {
		  			System.out.println(str);
		  		}
		  	}
		  	br.close();
	  }
	
  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

}
