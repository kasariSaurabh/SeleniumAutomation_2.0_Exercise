package com.components;

import com.objectRepository.Hms_Locators;
import com.utility.BaseClass;

public class HMSPRPageComponents extends BaseClass{
	Hms_Locators hmsLocators=new Hms_Locators();
	
	public void launchBrowser() throws Exception{
		try {
			openBrowser("chrome");
			openURL(readData.testDataValue.get("AppURL"));
			readData.addStepDetails("launchBrowser", "Browser Should launch", "successfully launched Browser", "Pass", "Y");
		} catch (Exception e) {
			readData.addStepDetails("launchBrowser", "Browser Should launch", "Failed to launch the browser", "Fail", "N");
		}
	}
	
	public void login() throws Exception{
		try {
			type(hmsLocators.username, readData.testDataValue.get("Username"));
			type(hmsLocators.password, readData.testDataValue.get("Password"));
			click(hmsLocators.login);
			readData.addStepDetails("login", "Application Should login", "successfully logged in", "Pass", "Y");
		} catch (Exception e) {
			readData.addStepDetails("login", "Application Should login", "Unable to login", "Fail", "N");
		}
	}
	
	public void navigateToReg() throws Exception{
		try {
			click(hmsLocators.registration);
			readData.addStepDetails("navigateToReg", "Application should navigate to PR page", "Successfully navigated to PR page", "Pass", "Y");
		} catch (Exception e) {
			readData.addStepDetails("navigateToReg", "Application should navigate to PR page", "Unable to navigate to PR page", "Fail", "N");
		}
		
	}
	

}





