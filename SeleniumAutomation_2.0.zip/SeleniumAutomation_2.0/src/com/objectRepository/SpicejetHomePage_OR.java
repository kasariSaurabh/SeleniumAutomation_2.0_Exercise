package com.objectRepository;

import org.openqa.selenium.By;

public class SpicejetHomePage_OR {
	
public By oneWayRB=By.xpath("//input[@id='ctl00_mainContent_rbtnl_Trip_1']");
public By from=By.xpath("//input[@id='ctl00_mainContent_ddl_originStation1_CTXT']");	
public By hyderabad=By.linkText("Hyderabad (HYD)");
public By bengaluru=By.linkText("Bengaluru (BLR)");
public By date=By.linkText("15");
public By Adult=By.xpath("//*[@id='ctl00_mainContent_ddl_Adult']");
public By Child=By.xpath("//*[@id='ctl00_mainContent_ddl_Child']");
public By Infants=By.xpath("//*[@id='ctl00_mainContent_ddl_Infant']");
public By Currency=By.xpath("//*[@id='ctl00_mainContent_DropDownListCurrency']");

}
