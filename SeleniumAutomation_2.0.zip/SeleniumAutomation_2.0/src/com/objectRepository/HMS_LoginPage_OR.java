package com.objectRepository;

import org.openqa.selenium.By;

public class HMS_LoginPage_OR {
	
	public By username= By.name("username");
	public By password = By.name("password");
	public By login = By.name("submit");

}
