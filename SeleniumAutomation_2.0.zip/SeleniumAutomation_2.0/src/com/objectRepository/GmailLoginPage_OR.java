package com.objectRepository;

import org.openqa.selenium.By;

public class GmailLoginPage_OR {
	public By username=By.xpath("//input[@id='identifierId']");
	public By next=By.xpath("//span[text()='Next']");	
	public By password=By.xpath("//input[@name='password']");
	public By signIn=By.xpath("//span[text()='Next']");
}
