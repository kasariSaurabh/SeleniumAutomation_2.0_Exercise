package com.objectRepository;

import org.openqa.selenium.By;

public class GmailLoginLocators1 {
	
	public By username = By.xpath("//input[@id=\"identifierId\"]");
	public By next = By.xpath("//span[text()='Next']");
	public By password = By.xpath("//input[@name=\"password\"]");

}
