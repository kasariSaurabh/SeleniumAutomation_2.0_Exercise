package com.testScripts;

import org.testng.annotations.Test;

import com.components.HMSPRPageComponents;
import com.utility.BaseClass;

public class HMSCreatePatientScript extends BaseClass{
	HMSPRPageComponents hmsPRPageComponents = new HMSPRPageComponents();
  @Test(description = "Test the create patient functionality")
  public void f() throws Exception {
	  readData.readTestDataFile("D:\\SeleniumWebdriver\\SeleniumAutomation_2.0\\TestData\\HMSTestData.xlsx","2");
	  hmsPRPageComponents.launchBrowser();
	  hmsPRPageComponents.login();
	  hmsPRPageComponents.navigateToReg();
  }
}
