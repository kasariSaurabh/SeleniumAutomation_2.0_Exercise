package testNG_Gmail;

import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class GoogleLinksLanguage {
	
	WebDriver driver;
	public void click(String str) {
		driver.findElement(By.xpath(str)).click();
	}
	
  @Test(description = "Verify Hindi link")
  public void test1() {
	  // driver.findElement(By.xpath("//*[@id=\'SIvCob\']/a[1]")).click(); 
	  click("//*[@id=\'SIvCob\']/a[1]");
  }
  
  @Test(description = "Verify Bengali link")
  public void test2() {
	  // driver.findElement(By.xpath("//*[@id=\'SIvCob\']/a[2]")).click(); 
	  click("//*[@id=\'SIvCob\']/a[2]");
  }
  
  @Test(description = "Verify Telugu link")
  public void test3() {
	  // driver.findElement(By.xpath("//*[@id=\'SIvCob\']/a[3]")).click(); 
	  click("//*[@id=\'SIvCob\']/a[3]");
  }
  
  @BeforeTest
  public void beforeTest() {
	  //System.setProperty("webdriver.chrome.driver", "D:\\lib\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Global wait
	  driver.get("http://google.co.in");
  }

  @AfterTest
  public void afterTest() {
	  driver.quit();
  }

}
