package testNG_Gmail;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class BugzillaSearch {
	WebDriver driver;
  @Test(description = "Verify Bugzilla Advanced Search")
  public void test1() throws Exception {
	  driver.findElement(By.xpath("//*[@id=\'header-nav\']/ul/li[2]/a/span[2]")).click();
	  Thread.sleep(2000);
		new Select(driver.findElement(By.xpath("//select[@id=\'product\']"))).selectByVisibleText("Air Mozilla");
		new Select(driver.findElement(By.xpath("//select[@id=\'product\']"))).selectByVisibleText("Bugzilla");
		new Select(driver.findElement(By.xpath("//select[@id=\'product\']"))).selectByVisibleText("Calendar");
		new Select(driver.findElement(By.xpath("//select[@id=\'product\']"))).selectByVisibleText("Cloud Services");
		Thread.sleep(2000);
		new Select(driver.findElement(By.xpath("//select[@id=\'component\']"))).selectByVisibleText("Administration");
		new Select(driver.findElement(By.xpath("//select[@id=\'component\']"))).selectByVisibleText("Alarms");
		new Select(driver.findElement(By.xpath("//select[@id=\'component\']"))).selectByVisibleText("Autograph");
		new Select(driver.findElement(By.xpath("//select[@id=\'component\']"))).selectByVisibleText("bugzilla.org");
		Thread.sleep(2000);
		new Select(driver.findElement(By.xpath("//select[@id=\'bug_status\']"))).selectByVisibleText("NEW");
		new Select(driver.findElement(By.xpath("//select[@id=\'bug_status\']"))).selectByVisibleText("ASSIGNED");
		new Select(driver.findElement(By.xpath("//select[@id=\'bug_status\']"))).selectByVisibleText("RESOLVED");
		new Select(driver.findElement(By.xpath("//select[@id=\'bug_status\']"))).selectByVisibleText("VERIFIED");
		Thread.sleep(2000);
		new Select(driver.findElement(By.xpath("//select[@id=\'resolution\']"))).selectByVisibleText("INVALID");
		new Select(driver.findElement(By.xpath("//select[@id=\'resolution\']"))).selectByVisibleText("INACTIVE");
		new Select(driver.findElement(By.xpath("//select[@id=\'resolution\']"))).selectByVisibleText("DUPLICATE");
		new Select(driver.findElement(By.xpath("//select[@id=\'resolution\']"))).selectByVisibleText("SUPPORT");
  }
  @Test(description = "Verify Bugzilla Advanced Search")
  public void test2() {
	  driver.findElement(By.id("Search")).click();  
  }
  
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver","D:\\lib\\chromedriver.exe");
	  driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  driver.get("https://bugzilla.mozilla.org/home");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(2000);
		driver.quit();
  }

}
