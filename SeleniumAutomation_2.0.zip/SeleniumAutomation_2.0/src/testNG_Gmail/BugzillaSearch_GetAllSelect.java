package testNG_Gmail;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class BugzillaSearch_GetAllSelect {
	WebDriver driver;
	@Test
  public void f() throws Exception {
	driver.findElement(By.xpath("//*[@id=\'header-nav\']/ul/li[2]/a/span[2]")).click();
	Thread.sleep(2000);
	new Select(driver.findElement(By.xpath("//select[@id=\'product\']"))).selectByVisibleText("Air Mozilla");
	new Select(driver.findElement(By.xpath("//select[@id=\'product\']"))).selectByVisibleText("Bugzilla");
	new Select(driver.findElement(By.xpath("//select[@id=\'product\']"))).selectByVisibleText("Calendar");
	new Select(driver.findElement(By.xpath("//select[@id=\'product\']"))).selectByVisibleText("Cloud Services");
	Thread.sleep(2000);
	new Select(driver.findElement(By.xpath("//select[@id=\'component\']"))).selectByVisibleText("Administration");
	new Select(driver.findElement(By.xpath("//select[@id=\'component\']"))).selectByVisibleText("Alarms");
	new Select(driver.findElement(By.xpath("//select[@id=\'component\']"))).selectByVisibleText("Autograph");
	new Select(driver.findElement(By.xpath("//select[@id=\'component\']"))).selectByVisibleText("bugzilla.org");
	
	List<WebElement> str = new Select(driver.findElement(By.xpath("//select[@id=\'component\']"))).getAllSelectedOptions();
	System.out.println(str.size());
	for(int i=0; i<str.size(); i++) {
		System.out.println(str.get(i).getText());
	}
  }
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver","D:\\lib\\chromedriver.exe");
	  driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  driver.get("https://bugzilla.mozilla.org/home");
  }

  @AfterTest
  public void afterTest() throws Exception {
	  Thread.sleep(3000);
	  driver.quit();
	  
  }

}
